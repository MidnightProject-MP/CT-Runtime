﻿# evidence_store

See lib/capabilities/definitions.mjs for contract. Adapter catalog: lib/capabilities/adapters.mjs

