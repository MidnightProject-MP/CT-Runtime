var CT_GAS_EVIDENCE = (function () {
  var folders=['observer','observer/inbox','observer/processed','observer/quarantine','observer/chronicle'];
  function root() { var id=PropertiesService.getScriptProperties().getProperty('CT_GAS_DRIVE_ROOT_ID'); if (!id) throw new Error('CT_GAS_DRIVE_ROOT_ID is required'); return DriveApp.getFolderById(id); }
  function folder(name) { if (folders.indexOf(name)<0) throw new Error('invalid evidence folder'); var current=root(); String(name).split('/').forEach(function (part) { var it=current.getFoldersByName(part); current=it.hasNext()?it.next():(current.createFolder?current.createFolder(part):root().createFolder(name)); }); return current; }
  function digest(text) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,text,Utilities.Charset.UTF_8).map(function (b) { return ('0'+(b<0?b+256:b).toString(16)).slice(-2); }).join(''); }
  function secrets() { var p=PropertiesService.getScriptProperties(); return ['OPENROUTER_API_KEY','GITHUB_TOKEN'].map(function (n) { return p.getProperty(n); }).filter(Boolean); }
   function withinRoot(file,rootId) {
     if (!file || !rootId) return false;
     if (!file.getParents) return true;
     var queue=[], seen={}, parents=file.getParents(), depth=0;
     while (parents && parents.hasNext() && depth++<16) queue.push(parents.next());
     for (var i=0;i<queue.length;i++) {
       var folder=queue[i], id=folder&&folder.getId?folder.getId():'';
       if (!id || seen[id]) continue;
       seen[id]=true;
       if (id===rootId) return true;
       if (folder.getParents) { var ancestors=folder.getParents(), count=0; while (ancestors&&ancestors.hasNext()&&count++<16) queue.push(ancestors.next()); }
     }
     return false;
   }
   function verifyExisting(fileId,hash,clock) { var run=function () { var file=DriveApp.getFileById(fileId), actual=digest(CT_GAS.bound(file.getBlob().getDataAsString(),64000)); if (actual!==hash) throw new Error('evidence hash mismatch'); if (!withinRoot(file,PropertiesService.getScriptProperties().getProperty('CT_GAS_DRIVE_ROOT_ID'))) throw new Error('evidence is outside configured Drive root'); if (file.getDescription) { var meta; try { meta=JSON.parse(file.getDescription()||'{}'); } catch (_) { throw new Error('evidence metadata invalid'); } if (meta.sha256!==hash || !meta.schema) throw new Error('evidence metadata mismatch'); } return {drive_file_id:file.getId(),sha256:actual}; }; return clock?CT_GAS.runGuard(clock,'drive-verify',3000,run):run(); }
   function put(data) { data=data || {}; var original=String(data.content==null?'':data.content), text=CT_GAS.redact(original,secrets()), hash=digest(text), schema=data.schema || 'celestan-execution-evidence-v1', refs=CT_GAS_STATE.list('evidence').filter(function (x) { return x.payload && x.payload.evidence_id===data.evidence_id && x.payload.sha256===hash; }); if (refs.length) return verifyExisting(refs[refs.length-1].payload.drive_file_id,hash,data.clock); if (text.length > CT_GAS.MAX_EVIDENCE_BYTES) throw new Error('evidence exceeds bound'); if (data.supersedes) { var old=CT_GAS_STATE.get('evidence',data.supersedes); if (!old || !old.payload || old.payload.execution_id!==data.execution_id) throw new Error('invalid evidence supersession'); }
      var kind=data.kind==='observer'?'observer':data.kind==='chronicle'?'observer/chronicle':data.quarantine?'observer/quarantine':'observer/inbox', file=folder(kind).createFile(Utilities.newBlob(text,data.mimeType || 'application/json',CT_GAS.bound(data.evidence_id || data.execution_id || 'evidence',80)+'-'+hash.slice(0,12))), provenance=JSON.parse(CT_GAS.json(data.provenance || {})); file.setDescription(JSON.stringify({schema:schema,evidence_id:data.evidence_id || null,physical_execution_id:data.physical_execution_id || data.execution_id || null,sha256:hash,provenance:provenance,original_length:original.length,stored_length:text.length,truncated:text.length<original.length})); if (data.clock && !data.clock.canStart(0)) return {status:'preempted',operation:'drive-put',reason:'post-operation-unsafe'}; CT_GAS_STATE.evidenceRef({evidence_id:data.evidence_id,execution_id:data.execution_id,physical_execution_id:data.physical_execution_id,drive_file_id:file.getId(),sha256:hash,schema:schema,provenance:provenance,supersedes:data.supersedes || null}); return {drive_file_id:file.getId(),sha256:hash,schema:schema,evidence_id:data.evidence_id}; }
  return {put:put,verifyExisting:verifyExisting,folders:function () { return folders.map(folder); }};
}());
function storeEvidence(data) { return CT_GAS_EVIDENCE.put(data); }
