import { readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { bundleHash, deploymentIdFromWebAppUrl, normalizeFiles, signature } from '../lib/gas-deploy-contract.mjs';
import { verifyWithReadback } from '../lib/gas-deploy-readback.mjs';
import { stateUncertainAfterMutation } from '../lib/gas-deploy-client.mjs';

const bundle = JSON.parse(await readFile(process.env.GAS_BUNDLE_PATH ?? 'gas-bundle.json', 'utf8'));
if (bundle.schema !== 'ct-runtime-gas-bundle-v1') throw new Error('invalid bundle schema');
const files = normalizeFiles(bundle.files);
const computed = bundleHash(files);
if (computed !== process.env.GAS_BUNDLE_HASH) throw new Error('bundle hash mismatch');

const scriptId = process.env.CT_GAS_SCRIPT_ID;
const endpoint = process.env.CT_GAS_ADMIN_WEB_APP_URL;
const deploymentId = deploymentIdFromWebAppUrl(endpoint);
const secret = process.env.CT_GAS_DEPLOY_HMAC_SECRET;
const commit = process.env.GITHUB_SHA;
const expectedLiveBundleHash = process.env.CT_GAS_EXPECTED_LIVE_BUNDLE_HASH;
for (const [name, value] of Object.entries({ scriptId, endpoint, secret, commit })) if (!value) throw new Error(`${name} is required`);
if (!/^[0-9a-f]{40}$/.test(commit)) throw new Error('GITHUB_SHA must be a full commit SHA');
const requestId = `ct-runtime-${commit}`;

async function post(body) {
  const url = new URL(endpoint);
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = randomBytes(24).toString('hex');
  const payload = JSON.stringify(body);
  const sig = signature(body, timestamp, nonce, payload, secret);
  url.searchParams.set('timestamp', timestamp);
  url.searchParams.set('nonce', nonce);
  url.searchParams.set('signature', sig);
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: payload,
    redirect: 'follow'
  });
  const text = await response.text();
  if (Buffer.byteLength(text) > 4 * 1024 * 1024) throw new Error('response too large');
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${text.slice(0, 1000)}`);
  if (!text.trim()) throw new Error(`empty response body (HTTP ${response.status})`);
  let value;
  try {
    value = JSON.parse(text);
  } catch (error) {
    throw new Error(`invalid JSON response (HTTP ${response.status}, request_bytes=${Buffer.byteLength(payload)}, response_url=${response.url}, redirected=${response.redirected}, content-type=${response.headers.get('content-type') || 'unknown'}): ${text.slice(0, 200)}`);
  }
  if (value.status === 'rejected') throw new Error(JSON.stringify(value));
  return value;
}

const base = { deployment_request_id: requestId, script_id: scriptId, deployment_id: deploymentId, commit_sha: commit, github_bundle_hash: computed };
const qualification = await post({ ...base, operation: 'self-deploy-qualify', files });
console.log(JSON.stringify({ qualification }, null, 2));
if (process.env.CT_GAS_QUALIFY_ONLY === '1') process.exit(0);
if (qualification.status !== 'qualified') throw new Error('self-deploy qualification failed');
const expectedGasBundleHash = qualification.desiredBundleHash;
if (!/^[0-9a-f]{64}$/.test(expectedGasBundleHash)) throw new Error('self-deploy qualification did not return a valid GAS-native desired bundle hash');
if (expectedLiveBundleHash && !/^[0-9a-f]{64}$/.test(expectedLiveBundleHash)) throw new Error('CT_GAS_EXPECTED_LIVE_BUNDLE_HASH must be a 64-character hex hash');
const plan = await post({ ...base, operation: 'self-deploy-plan' });
const livePredecessor = expectedLiveBundleHash ?? plan.liveBundleHash;
if (plan.liveBundleHash !== livePredecessor) throw new Error('live bundle does not match expected predecessor; refusing deployment');

const readback = () => post({ ...base, operation: 'self-deploy-plan' });
let result;
let needsReadback = false;

try {
  result = await post({ ...base, operation: 'self-deploy', expected_live_version: plan.liveVersion, expected_live_bundle_hash: livePredecessor, files });
} catch (error) {
  const uncertain = stateUncertainAfterMutation(error);
  console.error(JSON.stringify({
    status: uncertain.state,
    requestId,
    deploymentId,
    readbackRequired: uncertain.readbackRequired,
    error: uncertain.message
  }));
  needsReadback = true;
}

if (!needsReadback && result.githubBundleHash === computed && result.bundleHash === expectedGasBundleHash && result.headBundleHash === expectedGasBundleHash) {
  console.log(JSON.stringify({ ...result, qualification, requestId, commit, githubBundleHash: computed, deploymentId }));
  process.exit(0);
}

if (!needsReadback) {
  console.error('self-deploy response did not prove the requested GAS-native bundle is live; switching to readback verification');
}

try {
  const verified = await verifyWithReadback({ readback, expectedBundleHash: expectedGasBundleHash });
  result = {
    status: 'verified',
    requestId,
    deploymentId,
    versionNumber: verified.liveVersion,
    bundleHash: expectedGasBundleHash,
    githubBundleHash: computed,
    headBundleHash: expectedGasBundleHash,
    fileCount: verified.fileCount,
    readbackAttempts: verified.readbackAttempts
  };
  console.log(JSON.stringify({ ...result, qualification, commit }));
} catch (error) {
  console.error(error.message);
  process.exitCode = 2;
}
