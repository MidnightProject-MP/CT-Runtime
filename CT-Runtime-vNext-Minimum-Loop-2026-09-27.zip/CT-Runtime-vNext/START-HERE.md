# CT-Runtime vNext source delivery

The complete updated repository is in CT-Runtime/. Read CT-Runtime/DELIVERY-NOTES.md, then CT-Runtime/docs/VNEXT-PILOT.md.

Implemented and locally tested; not deployed or declared operational. The real backend, project authority/acceptance policy, native database checks, legacy exclusion and multi-day pilot remain activation work.

Run npm ci and npm test inside CT-Runtime. Keep the sibling CT-Foundry/ folder: it contains only the two pinned Observer contract files required by existing tests, from commit 5bb45fca93394800f533e75150599a54e6aaf96b. It is not a full Foundry checkout or a new production dependency.

No credentials, runtime data, node_modules or git history are included.
